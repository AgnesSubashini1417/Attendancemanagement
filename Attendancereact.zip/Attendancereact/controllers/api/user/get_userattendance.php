<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed']));
}

$data = json_decode(file_get_contents("php://input"), true);
$studentid = $data['studentid'];
$month = isset($data['month']) ? $data['month'] : null; // Optional
$year = isset($data['year']) ? $data['year'] : null; // Optional

$sql = "SELECT 
            MONTH(date) AS month, 
            YEAR(date) AS year, 
            COUNT(CASE WHEN status = 'Present' THEN 1 END) AS present_days, 
            COUNT(CASE WHEN status = 'Absent' THEN 1 END) AS absent_days
        FROM attendance
        WHERE Studentid = ?";

if ($month) {
    $sql .= " AND MONTH(date) = ?";
}
if ($year) {
    $sql .= " AND YEAR(date) = ?";
}

$sql .= " GROUP BY YEAR(date), MONTH(date) ORDER BY year, month";

$stmt = $conn->prepare($sql);

if ($month && $year) {
    $stmt->bind_param("sii", $studentid, $month, $year);
} elseif ($month) {
    $stmt->bind_param("si", $studentid, $month);
} elseif ($year) {
    $stmt->bind_param("si", $studentid, $year);
} else {
    $stmt->bind_param("s", $studentid);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $report = [];
    while ($row = $result->fetch_assoc()) {
        $report[] = [
            'month' => $row['month'],
            'year' => $row['year'],
            'present_days' => $row['present_days'],
            'absent_days' => $row['absent_days']
        ];
    }
    echo json_encode(['success' => true, 'report' => $report]);
} else {
    echo json_encode(['success' => false, 'message' => 'No attendance records found for this student']);
}

$stmt->close();
$conn->close();
?>
