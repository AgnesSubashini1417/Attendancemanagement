<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed']));
}

// Fetch all classes
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT * FROM classes";
    $result = $conn->query($sql);
    $classes = [];
    while ($row = $result->fetch_assoc()) {
        $classes[] = $row;
    }
    echo json_encode($classes);
}

// Add or Update class
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $classId = $_POST['Classid'];
    $className = $_POST['Classname'];

    $check = "SELECT * FROM classes WHERE Classid = '$classId'";
    $result = $conn->query($check);

    if ($result->num_rows > 0) {
        // Update if class already exists
        $sql = "UPDATE classes SET Classname='$className' WHERE Classid='$classId'";
    } else {
        // Insert if class doesn't exist
        $sql = "INSERT INTO classes (Classid, Classname) VALUES ('$classId', '$className')";
    }

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Class saved successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}

// Delete class
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $data = json_decode(file_get_contents("php://input"), true);
    $classId = $data['Classid'];

    $sql = "DELETE FROM classes WHERE Classid='$classId'";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Class deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error deleting class']);
    }
}

$conn->close();
?>
