<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed']));
}

if (isset($_GET['classId'])) {
    $studentclass = $_GET['classId'];
    $sql = "SELECT * FROM student WHERE studentclass = '$studentclass'";
    $result = $conn->query($sql);
    
    $students = [];
    while ($row = $result->fetch_assoc()) {
        $students[] = [
            'Studentid' => $row['Studentid'],
            'Studentname' => $row['studentname'],
        ];
    }
    
    echo json_encode(['success' => true, 'data' => $students]);
} else {
    echo json_encode(['success' => false, 'message' => 'Class ID not provided']);
}

$conn->close();
?>
