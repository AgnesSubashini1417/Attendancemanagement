<?php
// CORS headers to allow all origins (can be restricted to specific domains if needed)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed']));
}

// Fetch all students
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT * FROM student";
    $result = $conn->query($sql);
    $students = [];
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
    echo json_encode($students);
}

// Add or Update student
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Studentid = $_POST['Studentid'];
    $studentname = $_POST['studentname'];
    $studentclass = $_POST['studentclass'];

    $check = "SELECT * FROM student WHERE Studentid = '$Studentid'";
    $result = $conn->query($check);

    if ($result->num_rows > 0) {
        // Update if student exists
        $sql = "UPDATE student SET studentname='$studentname', studentclass='$studentclass' WHERE Studentid='$Studentid'";
    } else {
        // Insert if student doesn't exist
        $sql = "INSERT INTO student (Studentid, studentname, studentclass) VALUES ('$Studentid', '$studentname', '$studentclass')";
    }

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Student saved successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}

// Delete student
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $data = json_decode(file_get_contents("php://input"), true);
    $Studentid = $data['Studentid'];

    $sql = "DELETE FROM student WHERE Studentid='$Studentid'";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Student deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error deleting student']);
    }
}

$conn->close();
?>
