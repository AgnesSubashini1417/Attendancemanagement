<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed']));
}

if (isset($_GET['classId']) && isset($_GET['month'])) {
    $studentclass = $_GET['classId'];
    $month = $_GET['month']; // Expecting format YYYY-MM

    $year = substr($month, 0, 4);
    $monthNumber = substr($month, 5, 2);

    $sql = "SELECT Studentid, date, status 
            FROM attendance 
            WHERE studentclass = '$studentclass' 
              AND YEAR(date) = '$year' 
              AND MONTH(date) = '$monthNumber'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $attendance = [];

        while ($row = $result->fetch_assoc()) {
            $studentId = $row['Studentid'];
            $date = $row['date'];
            $status = strtolower(trim($row['status']));

            if (!isset($attendance[$studentId])) {
                $attendance[$studentId] = [];
            }

            $attendance[$studentId][$date] = ($status === 'present') ? 'Present' : 'Absent';
        }

        // Add all possible dates in the month (initialize all dates to null if no attendance data)
        $lastDay = date('t', strtotime($month));
        foreach ($attendance as $studentId => $dates) {
            for ($i = 1; $i <= $lastDay; $i++) {
                $dateKey = "$year-$monthNumber-" . str_pad($i, 2, '0', STR_PAD_LEFT);
                if (!isset($dates[$dateKey])) {
                    $attendance[$studentId][$dateKey] = null;  // No data for this date, set as null
                }
            }
        }

        $formattedAttendance = [];
        foreach ($attendance as $studentId => $dates) {
            $formattedAttendance[] = [
                'Studentid' => $studentId,
                'attendance' => $dates
            ];
        }

        echo json_encode(['success' => true, 'data' => $formattedAttendance]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No attendance records found']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Class ID or Month not provided']);
}

$conn->close();
?>
