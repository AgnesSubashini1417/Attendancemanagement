<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed']));
}

// Fetch classes if GET request is made
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['class'])) {
    $studentclass = $_GET['class'];
    $sql = "SELECT * FROM student WHERE studentclass = '$studentclass'";
    $result = $conn->query($sql);
    
    $students = [];
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
    echo json_encode($students);
    exit();
}

// Update attendance if POST request is made
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the request body
    $data = json_decode(file_get_contents("php://input"), true);

    if ($data) {
        error_log("Received Data: " . print_r($data, true));  // Debugging the received data
    } else {
        echo json_encode(['success' => false, 'message' => 'No data received']);
        exit();
    }

    if (isset($data['studentclass'], $data['date'], $data['records'])) {
        $studentclass = $data['studentclass'];
        $date = $data['date'];
        $records = $data['records'];

        foreach ($records as $record) {
            $Studentid = $record['Studentid'];
            $status = $record['status'];

            // Check if attendance record exists for the date
            $check = "SELECT * FROM attendance WHERE Studentid = '$Studentid' AND studentclass = '$studentclass' AND date = '$date'";
            $result = $conn->query($check);

            if ($result->num_rows > 0) {
                // Update existing record
                $sql = "UPDATE attendance SET status = '$status' WHERE Studentid = '$Studentid' AND studentclass = '$studentclass' AND date = '$date'";
            } else {
                // Insert new record
                $sql = "INSERT INTO attendance (Studentid, studentclass, date, status) VALUES ('$Studentid', '$studentclass', '$date', '$status')";
            }

            if ($conn->query($sql) === FALSE) {
                error_log("Error: " . $conn->error);  // Debugging error
                echo json_encode(['success' => false, 'message' => 'Error updating attendance']);
                exit();
            }
        }

        echo json_encode(['success' => true, 'message' => 'Attendance updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid data']);
    }
}

$conn->close();
?>
