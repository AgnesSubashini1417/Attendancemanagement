import React from 'react';
import Navbar from './Components/Navbar';
import ClassList from './Components/Classes';
import StudentList from './Components/Students';
import AttendanceForm from './Components/Attendance';
import AttendanceReport from './Components/Attendancereport';
import Admin from './Components/Admin';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashboard from './Components/Dashboard';
import Adminlogin from './Components/Adminlogin';
import User from './Components/User';
import Userdashboard from './Components/Userdashboard';
import StudentAttendanceReport from './Components/Studentattendancereport';
function App() {
  return (
    <div className="App">
      <Router>
   
          {/* Admin page without Navbar */}
         
        {/* Conditionally render Navbar based on the route */}
        <Routes>
          <Route path="/user" element={<User/>}/>
          
        <Route path="/" element={<Adminlogin />} />
          
        <Route path="/dashboard" element={<Dashboard />} />
          {/* Admin page without Navbar */}
          <Route path="/admin" element={<Admin />} />
          <Route path="/userdashboard" element={<Userdashboard />} />
          <Route path="/attendancestudent" element={<StudentAttendanceReport />} />




          {/* Other routes with Navbar */}
          <Route
            path="/class"
            element={
              <>
                <Navbar page="home" />
                <ClassList />
              </>
            }
          />
          <Route
            path="/students"
            element={
              <>
                <Navbar page="home" />
                <StudentList />
              </>
            }
          />
          <Route
            path="/attendance"
            element={
              <>
                <Navbar page="home" />
                <AttendanceForm />
              </>
            }
          />
          <Route
            path="/report"
            element={
              <>
                {/* <Navbar page="home" /> */}
                <AttendanceReport />
              </>
            }
          />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
