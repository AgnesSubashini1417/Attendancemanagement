import React, { useState, useEffect } from 'react';
import './Students.css';

const StudentForm = ({ student, onSave, onClose }) => {
    const [formData, setFormData] = useState({ class: '', name: '' });

    // This will run when 'student' prop changes
    useEffect(() => {
        if (student) {
            setFormData({ class: student.class, name: student.name });
        } else {
            setFormData({ class: '', name: '' }); // For new student
        }
    }, [student]); // Depend on the student prop

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave(formData); // Pass form data to onSave
    };

    return (
        <div className="modal">
            <div className="modal-header">
                <h2>{student ? 'Edit Student' : 'Add New Student'}</h2>
                <button className="close-btn" onClick={onClose}>X</button>
            </div>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Class</label>
                    <input 
                        type="text" 
                        name="class" 
                        value={formData.class} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <div className="form-group">
                    <label>Name</label>
                    <input 
                        type="text" 
                        name="name" 
                        value={formData.name} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <div className="form-actions">
                    <button type="submit" className="btn btn-primary">Save</button>
                    <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
                </div>
            </form>
        </div>
    );
};

export default StudentForm;
