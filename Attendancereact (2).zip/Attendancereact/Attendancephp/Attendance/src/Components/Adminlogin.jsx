import React from "react";
import { useNavigate } from "react-router-dom";
import "../Adminlogin.css"; // Ensure this file exists

const Adminlogin = () => {
  const navigate = useNavigate();

  return (
    <div className="login-container">
      <div className="page-title">
        Attendance Management System
        <hr />
      </div>
      <div className="button-group">
        <button className="nav-button" onClick={() => navigate("/admin")}>
          Admin
        </button>
        <button className="nav-button" onClick={() => navigate("/user")}>
          User
        </button>
      </div>
    </div>
  );
};

export default Adminlogin;
