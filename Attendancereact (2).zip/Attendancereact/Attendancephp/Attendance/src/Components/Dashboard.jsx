import React from 'react';
import Navbar from './Navbar'; // Import the Navbar component

const Dashboard = () => {
  return (
    <div>
      <Navbar page="home" />
      <div style={styles.container}>
        <h1 style={styles.welcomeMessage}>Welcome to Attendance Management System</h1>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh', // Full viewport height for vertical centering
    textAlign: 'center',
    backgroundColor: '#f8f9fa', // Optional: Background color for the page
  },
  welcomeMessage: {
    fontSize: '32px',
    fontWeight: 'bold',
    color: '#333',
  },
};

export default Dashboard;
