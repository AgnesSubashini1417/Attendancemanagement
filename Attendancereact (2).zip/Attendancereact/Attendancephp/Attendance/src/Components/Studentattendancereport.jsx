import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import './AttendanceReport.css';

const StudentAttendanceReport = () => {
  const location = useLocation();
  const { studentid, studentname } = location.state || {}; // Extract student details from location state

  const [attendanceData, setAttendanceData] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState('');
  const [error, setError] = useState('');

  // Fetch attendance data when the month or student changes
  useEffect(() => {
    if (!studentid || !selectedMonth) return;

    const fetchAttendanceData = async () => {
      try {
        const response = await fetch(
          `http://localhost/Attendancereact/controllers/api/user/get_attendance.php?studentid=${studentid}&month=${selectedMonth}`,
          {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' },
          }
        );
        const data = await response.json();
        if (data.success) {
          setAttendanceData(data.data.attendance);
          setError('');
        } else {
          setError(data.message || 'Failed to fetch attendance data');
        }
      } catch (error) {
        setError('Error fetching data. Please try again.');
        console.error('Error fetching attendance:', error);
      }
    };

    fetchAttendanceData();
  }, [selectedMonth, studentid]);

  return (
    <div className="attendance-report">
      <h1>Attendance Report for {studentname}</h1>
      
      {/* Month Selection Form */}
      <form>
        <div>
          <label>Select Month</label>
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
          />
        </div>
        {/* Filter button (centered) */}
        <button type="submit" className="filter-button" >
          Apply Filter
        </button>
      </form>

      {/* Error Handling */}
      {error && <p className="error-message">{error}</p>}

      {/* Attendance Data Table */}
      {selectedMonth && attendanceData && (
        <div>
          <h2>
            Attendance for {studentname} -{' '}
            {new Date(selectedMonth).toLocaleString('default', { month: 'long' })} {new Date(selectedMonth).getFullYear()}
          </h2>

          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(attendanceData).map((date) => (
                <tr key={date}>
                  <td>{date}</td>
                  <td className={attendanceData[date] === 'Present' ? 'text-success' : 'text-danger'}>
                    {attendanceData[date]}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default StudentAttendanceReport;
