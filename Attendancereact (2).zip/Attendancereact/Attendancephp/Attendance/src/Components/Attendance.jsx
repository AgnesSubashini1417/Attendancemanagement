import React, { useState, useEffect } from 'react';
import './Attendance.css';

const AttendanceForm = () => {
  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [attendanceDate, setAttendanceDate] = useState('');
  const [students, setStudents] = useState([]);

  // Fetch classes when component loads
  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const response = await fetch('http://localhost/Attendancereact/controllers/api/admin/post/get_classes.php');
        const data = await response.json();
        setClasses(data);
      } catch (error) {
        console.error('Error fetching classes:', error);
      }
    };

    fetchClasses();
  }, []);

  // Fetch students based on selected class
  useEffect(() => {
    const fetchStudents = async () => {
      if (!selectedClass) return;
      try {
        const response = await fetch(`http://localhost/Attendancereact/controllers/api/admin/post/get_students.php?class=${selectedClass}`);
        const data = await response.json();
        setStudents(data);
      } catch (error) {
        console.error('Error fetching students:', error);
      }
    };

    fetchStudents();
  }, [selectedClass]);

  const handleStatusChange = (id, newStatus) => {
    const updatedStudents = students.map(student =>
      student.Studentid === id ? { ...student, status: newStatus } : student
    );
    setStudents(updatedStudents);
  };

  const handleSubmit = async () => {
    if (!attendanceDate) {
      alert('Please select a date!');
      return;
    }

    const attendanceData = {
      studentclass: selectedClass,
      date: attendanceDate,
      records: students.map(student => ({
        Studentid: student.Studentid,
        status: student.status ? student.status : 'Absent', // Default to 'Absent' only if no status is explicitly set
      }))
    };

    console.log('Attendance Data:', attendanceData); // Debugging the data before sending it

    try {
      const response = await fetch('http://localhost/Attendancereact/controllers/api/admin/post/attendancepost.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(attendanceData),
      });

      const result = await response.json();

      if (result.success) {
        alert(`Attendance for ${selectedClass} on ${attendanceDate} submitted!`);
      } else {
        alert('Error submitting attendance');
      }
    } catch (error) {
      console.error('Error submitting attendance:', error);
      alert('Error submitting attendance');
    }
  };

  return (
    <div className="attendance-container">
      <h1>Attendance Management</h1>

      <div className="filters">
        <div className="filter-group">
          <label htmlFor="class">Select Class</label>
          <select
            id="class"
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
          >
            <option value="">Select a class</option>
            {classes.map(cls => (
              <option key={cls} value={cls}>{cls}</option>
            ))}
          </select>
        </div>

        <div className="filter-group">
          <label htmlFor="date">Select Date</label>
          <input
            type="date"
            id="date"
            value={attendanceDate}
            onChange={(e) => setAttendanceDate(e.target.value)}
          />
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th>Student ID</th>
            <th>Name</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {students.map(student => (
            <tr key={student.Studentid}>
              <td>{student.Studentid}</td>
              <td>{student.studentname}</td>
              <td>
                <select
                  value={student.status || 'Absent'} // Default to 'Absent' only for rendering, not in state
                  onChange={(e) => handleStatusChange(student.Studentid, e.target.value)}
                >
                  <option value="Present">Present</option>
                  <option value="Absent">Absent</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <button onClick={handleSubmit}>Submit Attendance</button>
    </div>
  );
};

export default AttendanceForm;
