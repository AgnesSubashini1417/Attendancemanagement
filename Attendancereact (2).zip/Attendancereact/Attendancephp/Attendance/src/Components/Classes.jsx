import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Class.css'; // For custom CSS

const ClassList = () => {
    const [classes, setClasses] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [formData, setFormData] = useState({ Classid: '', Classname: '' });
    const [isEdit, setIsEdit] = useState(false);

    useEffect(() => {
        fetchClasses();
    }, []);

    // Fetch all classes from the backend
    const fetchClasses = async () => {
        try {
            const response = await axios.get('http://localhost/Attendancereact/controllers/api/admin/post/post.php');
            setClasses(response.data);
        } catch (error) {
            console.error('Error fetching classes:', error);
        }
    };

    const handleAddClass = () => {
        setFormData({ Classid: '', Classname: '' });
        setIsEdit(false);
        setShowModal(true);
    };

    const handleEdit = (cls) => {
        setFormData(cls);
        setIsEdit(true);
        setShowModal(true);
    };

    const handleDelete = async (Classid) => {
        if (window.confirm('Are you sure you want to delete this class?')) {
            try {
                const response = await axios.delete(
                    'http://localhost/Attendancereact/controllers/api/admin/post/post.php',
                    { data: { Classid } }
                );
                if (response.data.success) {
                    fetchClasses();
                } else {
                    alert(response.data.message);
                }
            } catch (error) {
                console.error('Error deleting class:', error);
            }
        }
    };

    const handleSave = async (e) => {
        e.preventDefault();
        const formDataEncoded = new URLSearchParams();
        formDataEncoded.append('Classid', formData.Classid);
        formDataEncoded.append('Classname', formData.Classname);

        try {
            const response = await axios.post(
                'http://localhost/Attendancereact/controllers/api/admin/post/post.php',
                formDataEncoded,
                { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
            );

            if (response.data.success) {
                fetchClasses();
                setShowModal(false);
            } else {
                alert(response.data.message);
            }
        } catch (error) {
            console.error('Error saving class:', error);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    return (
        <div className="container">
            <div className="page-title mb-3">List of Classes</div>
            <hr />
            <div className="row justify-content-center">
                <div className="col-lg-8 col-md-10 col-sm-12">
                    <div className="card shadow">
                        <div className="card-header d-flex justify-content-end">
                            <button
                                className="btn btn-primary btn-sm rounded-0"
                                onClick={handleAddClass}
                            >
                                Add New
                            </button>
                        </div>
                        <div className="card-body">
                            <div className="table-responsive">
                                <table className="table table-bordered table-hover">
                                    <thead className="bg-dark-subtle">
                                        <tr>
                                            <th className="text-center">ID</th>
                                            <th className="text-center">Class Name</th>
                                            <th className="text-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {classes.length > 0 ? (
                                            classes.map((cls) => (
                                                <tr key={cls.Classid}>
                                                    <td className="text-center">{cls.Classid}</td>
                                                    <td>{cls.Classname}</td>
                                                    <td className="text-center">
                                                        <button
                                                            className="btn btn-warning btn-sm me-2"
                                                            onClick={() => handleEdit(cls)}
                                                        >
                                                            Edit
                                                        </button>
                                                        <button
                                                            className="btn btn-danger btn-sm"
                                                            onClick={() => handleDelete(cls.Classid)}
                                                        >
                                                            Delete
                                                        </button>
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                            <tr>
                                                <td colSpan="3" className="text-center">No data found.</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {showModal && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <form onSubmit={handleSave}>
                            <div className="mb-3">
                                <label htmlFor="Classid" className="form-label">
                                    Class ID
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="Classid"
                                    name="Classid"
                                    value={formData.Classid}
                                    onChange={handleChange}
                                    required
                                    disabled={isEdit}
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="Classname" className="form-label">
                                    Class Name
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="Classname"
                                    name="Classname"
                                    value={formData.Classname}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="d-flex justify-content-end">
                                <button
                                    type="button"
                                    className="btn btn-secondary me-2"
                                    onClick={() => setShowModal(false)}
                                >
                                    Cancel
                                </button>
                                <button type="submit" className="btn btn-primary">
                                    {isEdit ? 'Update' : 'Save'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ClassList;
