import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';

const UserDashboard = () => {
  const location = useLocation();
  const studentname = location.state?.studentname || 'Student';
  const studentid = location.state?.studentid;

  const [attendanceReport, setAttendanceReport] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [month, setMonth] = useState('');
  const [year, setYear] = useState('');

  const fetchAttendance = () => {
    setLoading(true);
    setError('');

    axios
      .post('http://localhost/Attendancereact/controllers/api/user/get_userattendance.php', {
        studentid,
        month: month || null,
        year: year || null,
      })
      .then((response) => {
        if (response.data.success) {
          setAttendanceReport(response.data.report);
        } else {
          setError(response.data.message);
        }
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching attendance:', error);
        setError('Failed to fetch attendance report.');
        setLoading(false);
      });
  };

  useEffect(() => {
    if (studentid) {
      fetchAttendance(); // Fetch initial attendance report
    }
  }, [studentid]);

  const handleFilter = () => {
    fetchAttendance(); // Fetch filtered attendance report
  };

  if (loading) return <p>Loading attendance report...</p>;
  if (error) return <p style={{ color: 'red' }}>{error}</p>;

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome, {studentname}!</h1>
      <h2>Your Attendance Report</h2>

      <div style={{ marginBottom: '20px' }}>
        <label>
          Select Month:
          <select value={month} onChange={(e) => setMonth(e.target.value)}>
            <option value="">All</option>
            {[...Array(12)].map((_, i) => (
              <option key={i + 1} value={i + 1}>
                {i + 1}
              </option>
            ))}
          </select>
        </label>
        <label>
          Select Year:
          <input
            type="number"
            placeholder="Enter year"
            value={year}
            onChange={(e) => setYear(e.target.value)}
            style={{ marginLeft: '10px' }}
          />
        </label>
        <button onClick={handleFilter} style={{ marginLeft: '10px' }}>
          Filter
        </button>
      </div>

      {attendanceReport.length > 0 ? (
        <table border="1" style={{ margin: 'auto', textAlign: 'center', width: '80%' }}>
          <thead>
            <tr>
              <th>Month</th>
              <th>Year</th>
              <th>Present Days</th>
              <th>Absent Days</th>
            </tr>
          </thead>
          <tbody>
            {attendanceReport.map((record, index) => (
              <tr key={index}>
                <td>{record.month}</td>
                <td>{record.year}</td>
                <td>{record.present_days}</td>
                <td>{record.absent_days}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No attendance records found.</p>
      )}
    </div>
  );
};

export default UserDashboard;
