import React, { useState, useEffect } from 'react';
import './AttendanceReport.css';

const AttendanceReport = () => {
  const [classList, setClassList] = useState([]);
  const [studentList, setStudentList] = useState([]);
  const [attendanceData, setAttendanceData] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('');
  const [monthLastDay, setMonthLastDay] = useState(0);

  // Fetch the list of classes
  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const response = await fetch('http://localhost/Attendancereact/controllers/api/admin/post/get_classes.php');
        const data = await response.json();
        setClassList(data);
      } catch (error) {
        console.error('Error fetching class list:', error);
      }
    };
    fetchClasses();
  }, []);

  // Fetch students for the selected class
  useEffect(() => {
    const fetchStudents = async () => {
      if (!selectedClass) return;

      try {
        const response = await fetch(`http://localhost/Attendancereact/controllers/api/admin/post/students.php?classId=${selectedClass}`);
        const data = await response.json();
        if (data.success) {
          setStudentList(data.data);
        } else {
          console.error('Error fetching students:', data.message);
        }
      } catch (error) {
        console.error('Error fetching students:', error);
      }
    };
    fetchStudents();
  }, [selectedClass]);

  // Fetch attendance records for the selected class and month
  useEffect(() => {
    const fetchAttendance = async () => {
      if (!selectedClass || !selectedMonth) return;

      const [year, month] = selectedMonth.split('-');
      const lastDay = new Date(year, month, 0).getDate();
      setMonthLastDay(lastDay);

      try {
        const response = await fetch(
          `http://localhost/Attendancereact/controllers/api/admin/post/get_attendance.php?classId=${selectedClass}&month=${selectedMonth}`
        );
        const data = await response.json();
        if (data.success) {
          setAttendanceData(data.data);
        } else {
          console.error('Error fetching attendance:', data.message);
        }
      } catch (error) {
        console.error('Error fetching attendance:', error);
      }
    };
    fetchAttendance();
  }, [selectedClass, selectedMonth]);

  // Calculate total present days for each student
  const calculateTotalPresent = (attendance) => {
    return Object.values(attendance || {}).filter((status) => status === 'Present').length;
  };

  return (
    <div className="attendance-report">
      <h1>Attendance Report</h1>
      <form>
        <div className="filters">
          <div>
            <label>Class</label>
            <select value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)}>
              <option value="">-- Select Class --</option>
              {classList.map((cls) => (
                <option key={cls} value={cls}>
                  {cls}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label>Month</label>
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
            />
          </div>
        </div>
      </form>

      {selectedClass && selectedMonth && (
        <div>
          <h2>
            {selectedClass} - {new Date(selectedMonth).toLocaleString('default', { month: 'long' })}
          </h2>
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Student Name</th>
                  {[...Array(monthLastDay)].map((_, i) => (
                    <th key={i + 1}>{i + 1}</th>
                  ))}
                  <th>Total Present</th>
                </tr>
              </thead>
              <tbody>
                {studentList.map((student) => {
                  const studentAttendance = attendanceData.find(
                    (att) => parseInt(att.Studentid, 10) === parseInt(student.Studentid, 10)
                  )?.attendance || {};

                  return (
                    <tr key={student.Studentid}>
                      <td>{student.Studentname}</td>
                      {[...Array(monthLastDay)].map((_, i) => {
                        const day = `${selectedMonth}-${String(i + 1).padStart(2, '0')}`;
                        const status = studentAttendance[day] !== undefined ? studentAttendance[day] : null; // Set null if unmarked
                        return (
                          <td key={i} className={status === 'Present' ? 'text-success' : status === 'Absent' ? 'text-danger' : ''}>
                            {status || 'nil'}
                          </td>
                        );
                      })}
                      <td>{calculateTotalPresent(studentAttendance)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttendanceReport;
