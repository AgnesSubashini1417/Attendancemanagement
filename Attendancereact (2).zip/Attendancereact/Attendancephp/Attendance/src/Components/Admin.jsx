import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation
import './Home.css'; // Import the CSS for styling

const Admin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate(); // Initialize the navigate function

  const handleSubmit = (e) => {
    e.preventDefault();
    // Check if username and password match
    if (username === 'admin@gmail.com' && password === 'admin') {
      // Redirect to the home page or dashboard
      navigate('/dashboard'); // Replace with the actual route you want to go to
    } else {
      // Show an error message if login fails
      alert('Invalid username or password!');
    }
  };

  return (
    <div className="login-container">
      <div className="page-title">
        Attendance Management System
        <hr />
      </div>

      <form onSubmit={handleSubmit} className="login-form">
        <div className="input-container">
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Enter your username"
            required
          />
        </div>

        <div className="input-container">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
            required
          />
        </div>

        <button type="submit" className="submit-button">Login</button>
      </form>
    </div>
  );
};

export default Admin;
