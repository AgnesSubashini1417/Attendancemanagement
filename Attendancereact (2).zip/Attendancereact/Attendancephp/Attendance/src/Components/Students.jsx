import React, { useState, useEffect } from 'react';
import axios from 'axios';

const StudentList = () => {
    const [students, setStudents] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [formData, setFormData] = useState({ Studentid: '', studentname: '', studentclass: '' });
    const [isEdit, setIsEdit] = useState(false);

    useEffect(() => {
        fetchStudents();
    }, []);

    // Fetch all students from the backend
    const fetchStudents = async () => {
        try {
            const response = await axios.get('http://localhost/Attendancereact/controllers/api/admin/post/studentpost.php');
            if (response.data) {
                setStudents(response.data);
            } else {
                console.error('No data received');
            }
        } catch (error) {
            console.error('Error fetching students:', error);
        }
    };

    // Handle the Add Student button click
    const handleAddStudent = () => {
        setFormData({ Studentid: '', studentname: '', studentclass: '' });
        setIsEdit(false);
        setShowModal(true);
    };

    // Handle Edit student
    const handleEdit = (student) => {
        setFormData(student);
        setIsEdit(true);
        setShowModal(true);
    };

    // Handle Delete student
    const handleDelete = async (Studentid) => {
        if (window.confirm('Are you sure you want to delete this student?')) {
            try {
                const response = await axios.delete(
                    'http://localhost/Attendancereact/controllers/api/admin/post/studentpost.php',
                    { data: { Studentid } }
                );
                if (response.data.success) {
                    fetchStudents();
                } else {
                    alert(response.data.message);
                }
            } catch (error) {
                console.error('Error deleting student:', error);
            }
        }
    };

    // Handle saving or updating the student
    const handleSave = async (e) => {
        e.preventDefault();
        const formDataEncoded = new URLSearchParams();
        formDataEncoded.append('Studentid', formData.Studentid);
        formDataEncoded.append('studentname', formData.studentname);
        formDataEncoded.append('studentclass', formData.studentclass);

        try {
            const response = await axios.post(
                'http://localhost/Attendancereact/controllers/api/admin/post/studentpost.php',
                formDataEncoded,
                { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
            );

            if (response.data.success) {
                fetchStudents();
                setShowModal(false);
            } else {
                alert(response.data.message);
            }
        } catch (error) {
            console.error('Error saving student:', error);
        }
    };

    // Handle input field changes
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    return (
        <div className="container">
            <div className="page-title mb-3">List of Students</div>
            <hr />
            <button
                className="btn btn-primary"
                onClick={handleAddStudent}
            >
                Add New Student
            </button>
            <div className="table-responsive">
                <table className="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th className="text-center">ID</th>
                            <th className="text-center">Name</th>
                            <th className="text-center">Class</th>
                            <th className="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {students.length > 0 ? (
                            students.map((student) => (
                                <tr key={student.Studentid}>
                                    <td className="text-center">{student.Studentid}</td>
                                    <td>{student.studentname}</td>
                                    <td>{student.studentclass}</td>
                                    <td className="text-center">
                                        <button
                                            className="btn btn-warning btn-sm me-2"
                                            onClick={() => handleEdit(student)}
                                        >
                                            Edit
                                        </button>
                                        <button
                                            className="btn btn-danger btn-sm"
                                            onClick={() => handleDelete(student.Studentid)}
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="4" className="text-center">No data found</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {showModal && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <form onSubmit={handleSave}>
                            <div className="mb-3">
                                <label htmlFor="Studentid" className="form-label">
                                    Student ID
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="Studentid"
                                    name="Studentid"
                                    value={formData.Studentid}
                                    onChange={handleChange}
                                    required
                                    disabled={isEdit}
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="studentname" className="form-label">
                                    Student Name
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="studentname"
                                    name="studentname"
                                    value={formData.studentname}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="studentclass" className="form-label">
                                    Class Name
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="studentclass"
                                    name="studentclass"
                                    value={formData.studentclass}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="d-flex justify-content-end">
                                <button
                                    type="button"
                                    className="btn btn-secondary me-2"
                                    onClick={() => setShowModal(false)}
                                >
                                    Cancel
                                </button>
                                <button type="submit" className="btn btn-primary">
                                    {isEdit ? 'Update' : 'Save'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default StudentList;
