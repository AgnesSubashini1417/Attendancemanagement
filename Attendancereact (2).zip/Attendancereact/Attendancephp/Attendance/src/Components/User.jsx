import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './User.css'; // Import the CSS for styling

const User = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Make a POST request to verify login
    const response = await fetch('http://localhost/Attendancereact/controllers/api/user/login.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ studentname: username, Studentid: password }),
    });

    const data = await response.json();

    if (data.success) {
      // Redirect to the dashboard and pass the studentid
      navigate('/userdashboard', { state: { studentname: username, studentid: data.studentid } });
    } else {
      alert(data.message || 'Login failed. Please try again.');
    }
  };

  return (
    <div className="login-container">
      <div className="page-title">
        Attendance Management System
        <hr />
      </div>

      <form onSubmit={handleSubmit} className="login-form">
        <div className="input-container">
          <label htmlFor="username">Username (Student Name):</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Enter your username"
            required
          />
        </div>

        <div className="input-container">
          <label htmlFor="password">Password (Student ID):</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
            required
          />
        </div>

        <button type="submit" className="submit-button">Login</button>
      </form>
    </div>
  );
};

export default User;
